﻿namespace DesignPatternSamples.Application.DTO
{
    public class Veiculo
    {
        public string Placa { get; set; }
        public string UF { get; set; }
    }
}